# Pixelary
a pixel-perfect monospace font, with binary strips.

Pixelary is based on [Paskowy](https://www.dafont.com/paskowy.font).

Both Paskowy and Pixelary are free to use, privately and commercially.

https://user-images.githubusercontent.com/42698687/187075962-2478e467-b96b-419f-98c6-529dddbbbb9b.mp4

## Alphabet

![splash](https://github.com/patchstep/Pixelary/blob/main/splash.png?raw=true)
